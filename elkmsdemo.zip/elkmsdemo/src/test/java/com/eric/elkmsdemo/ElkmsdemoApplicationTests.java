package com.eric.elkmsdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElkmsdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
