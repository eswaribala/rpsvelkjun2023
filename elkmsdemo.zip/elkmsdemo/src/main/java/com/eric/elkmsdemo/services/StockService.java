package com.eric.elkmsdemo.services;

import java.util.ArrayList;
import java.util.List;

import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.Query;
import org.springframework.data.elasticsearch.core.query.StringQuery;
import org.springframework.stereotype.Service;
import org.springframework.data.elasticsearch.core.mapping.IndexCoordinates;
import com.eric.elkmsdemo.models.Stock;
import com.eric.elkmsdemo.repositories.StockRepository;

@Service
public class StockService {
    @Autowired
	private StockRepository stockRepository;
    private static final String STOCK_INDEX = "stockdataindex";
    @Autowired
    private ElasticsearchOperations elasticsearchOperations;
    
    public Stock createStockIndex(final Stock stock)
    {
        return stockRepository.save(stock);
    }

    public Iterable<Stock> createStockIndices(final List<Stock> stockList)
    {
        return stockRepository.saveAll(stockList);
    }

    public List<Stock> getAllStockForLocation (String location)
    {
        return stockRepository.findByLocation(location);
    }

    public Stock findById (long stockId)
    {
        return stockRepository.findById(stockId).get();
    }

    public List<Stock> findByProductId (long productId)
    {
        return stockRepository.findByProductId(productId);
    }

    
    public List<Stock> findStocksByLocation(final String location) {

    	QueryBuilder queryBuilder = QueryBuilders
				.matchQuery("location", location);
		// .fuzziness(0.8)
		// .boost(1.0f)
		// .prefixLength(0)
		// .fuzzyTranspositions(true);

		Query searchQuery = new NativeSearchQueryBuilder()
				.withQuery(queryBuilder)
				.build();
      
     // 2. Execute search
     		SearchHits<Stock> stockHits = 
     				elasticsearchOperations
     		          .search(searchQuery, 
     		              Stock.class,
     		              IndexCoordinates.of(STOCK_INDEX));

     		// 3. Map searchHits to product list
     		List<Stock> stockMatches = new ArrayList<Stock>();
     		stockHits.forEach(srchHit->{
     			stockMatches.add(srchHit.getContent());
     		});
     		
     		return stockMatches;
      }
    
		/*
		 * public List<Stock> findStocksByLocation(final String location) {
		 * 
		 * Query searchQuery = new StringQuery(
		 * "{\"match\":{\"location\":{\"query\":\""+ location + "\"}}}\"");
		 * 
		 * 
		 * 
		 * // 2. Execute search SearchHits<Stock> stockHits = elasticsearchOperations
		 * .search(searchQuery, Stock.class, IndexCoordinates.of(STOCK_INDEX));
		 * 
		 * // 3. Map searchHits to product list List<Stock> stockMatches = new
		 * ArrayList<Stock>(); stockHits.forEach(srchHit->{
		 * stockMatches.add(srchHit.getContent()); });
		 * 
		 * return stockMatches; }
		 */
    
    public List<String> fetchSuggestions(String query) {
		QueryBuilder queryBuilder = QueryBuilders
				.wildcardQuery("location", query+"*");

		Query searchQuery = new NativeSearchQueryBuilder()
				.withFilter(queryBuilder)
				//.withPageable(PageRequest.of(0, 5))
				.build();

		SearchHits<Stock> searchSuggestions = 
				elasticsearchOperations.search(searchQuery, 
						Stock.class,
				IndexCoordinates.of(STOCK_INDEX));
		
		List<String> suggestions = new ArrayList<String>();
		
		searchSuggestions.getSearchHits().forEach(searchHit->{
			suggestions.add(searchHit.getContent().getLocation());
		});
		return suggestions;
	}
}
